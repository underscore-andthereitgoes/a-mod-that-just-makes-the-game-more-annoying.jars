package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.landmines;

import com.mojang.math.Transformation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.jspecify.annotations.Nullable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.stream.Collectors;


public class Landmine {

  public static final float NEAR_FOLLOW_RANGE = 64.0f;
  public static final float FAR_FOLLOW_RANGE = 256.0f;
  public static final float MOVE_SPEED = 0.1f;
  public static final Direction[] PLANAR_HORIZONTAL = Direction.Plane.HORIZONTAL.stream().toArray(Direction[]::new);

  public final Display.BlockDisplay blockDisplay;
  private final ServerLevel level;
  public BlockPos position;
  public Vec3 movingPosition;
  public int moveCooldown;
  private boolean steppedOn = false;
  private boolean moving;
  private @Nullable String lastEntityTag = null;

  public Landmine(Display.BlockDisplay blockDisplay, ServerLevel level) {
    this.blockDisplay = blockDisplay;
    this.level = level;
    this.blockDisplay
        .entityTags()
        .stream()
        .filter(tag -> tag.matches("cooldown\\.\\d+"))
        .findAny()
        .ifPresent(tag -> this.moveCooldown = Integer.parseUnsignedInt(tag.substring(9)));
    this.blockDisplay
        .entityTags()
        .stream()
        .collect(Collectors.toUnmodifiableSet())
        .stream()
        .filter(tag -> tag.matches("cooldown\\.\\d+"))
        .forEach(this.blockDisplay::removeTag);
    this.position = BlockPos.containing(blockDisplay.position());
    this.movingPosition = blockDisplay.position();
    this.moving = this.moveCooldown == 0;
    this.updateBlockDisplay();
  }

  public void updateBlockDisplay() {
    this.blockDisplay.setCustomName(Component.literal("Landmine"));
    this.blockDisplay.addTag("landmine");
    this.blockDisplay.setTransformation(new Transformation(
        new Vector3f(-0.5f, -0.5f, 0.0625f),
        new Quaternionf(new AxisAngle4f(Mth.PI * -0.5f, 1f, 0f, 0f)),
        new Vector3f(1f),
        new Quaternionf()
    ));
    this.updateBlockDisplayBlock();
    this.updateBlockDisplayTag();
    this.moveBlockDisplay();
  }

  public void updateBlockDisplayBlock() {
    if (this.steppedOn) {
      this.blockDisplay.setBlockState(Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE.defaultBlockState());
    } else {
      this.blockDisplay.setBlockState(Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE.defaultBlockState());
    }
  }

  public void updateBlockDisplayTag() {
    if (this.lastEntityTag != null) {
      this.blockDisplay.removeTag(this.lastEntityTag);
      this.lastEntityTag = null;
    }
    if (this.moveCooldown > 0) this.blockDisplay.addTag(this.lastEntityTag = "cooldown." + this.moveCooldown);
  }

  public void moveBlockDisplay() {
    this.blockDisplay.setPos(this.movingPosition);
    this.blockDisplay.setXRot(90f);
    this.blockDisplay.setYRot(0f);
  }

  public void tick() {

    if (!Config.LANDMINES.get()) {
      this.blockDisplay.remove(Entity.RemovalReason.DISCARDED);
      return;
    }

    boolean canMove = !this.steppedOn;
    boolean instantMove = false;

    BlockPos supportingBlockPos = this.position.below();
    if (this.level.isLoaded(supportingBlockPos)) {
      if (!this.level.getBlockState(supportingBlockPos).isFaceSturdy(level, supportingBlockPos, Direction.UP)) {
        if (!this.moving) this.steppedOn = true;
        this.position = this.position.below();
        canMove = false;
        this.moving = true;
      } else if (this.level.getBlockState(this.position).isFaceSturdy(level, this.position, Direction.UP)) {
        this.position = this.position.above();
        canMove = false;
        this.moving = true;
      }
    } else {
      this.blockDisplay.remove(Entity.RemovalReason.DISCARDED);
      return;
    }

    this.updateBlockDisplayTag();

    Vec3 sourcePosition = Vec3.atBottomCenterOf(this.position);
    LivingEntity nearestEntity = this.level.getNearestEntity(LivingEntity.class, TargetingConditions.forCombat(), (LivingEntity)null, sourcePosition.x, sourcePosition.y, sourcePosition.z, AABB.ofSize(sourcePosition, FAR_FOLLOW_RANGE * 2d, FAR_FOLLOW_RANGE * 2d, FAR_FOLLOW_RANGE * 2d));
    if (nearestEntity != null && nearestEntity.distanceToSqr(sourcePosition) > FAR_FOLLOW_RANGE * FAR_FOLLOW_RANGE) nearestEntity = null;
    if ((nearestEntity != null && nearestEntity.distanceToSqr(sourcePosition) >= NEAR_FOLLOW_RANGE * NEAR_FOLLOW_RANGE && (instantMove = true)) || this.moveCooldown <= 0) {
      if (canMove) {
        this.moveCooldown = Mth.lerpInt((float)Math.random(), 100, 400);
        Direction walkDirection = PLANAR_HORIZONTAL[Mth.floor(Math.random() * PLANAR_HORIZONTAL.length)];
        boolean walk = Math.random() < 0.02d;
        if (nearestEntity != null) {
          walkDirection = Direction.getApproximateNearest(nearestEntity.position().subtract(sourcePosition).horizontal());
          walk = true;
        }
        if (walk) {
          this.position = this.position.relative(walkDirection);
          this.moving = true;
        }
      }
    } else {
      this.moveCooldown--;
    }

    boolean wasSteppedOn = this.steppedOn;
    boolean isSteppedOn = false;

    if (this.moving) {
      Vec3 targetMovePosition = Vec3.atBottomCenterOf(this.position).add(0d, 0.0625d, 0d);
      Vec3 offset = targetMovePosition.subtract(this.movingPosition);
      double moveAmount = offset.horizontalDistance();
      if (moveAmount > MOVE_SPEED && !instantMove) {
        moveAmount = MOVE_SPEED;
      } else {
        this.moving = false;
      }
      Vec3 newPosition = this.movingPosition.add(offset.horizontal().normalize().scale(moveAmount));
      this.movingPosition = new Vec3(newPosition.x, targetMovePosition.y, newPosition.z);
      this.moveBlockDisplay();
    } else {
      AABB myBB = new AABB(this.position).contract(0.0d, 0.75d, 0.0d);
      if (nearestEntity != null) {
        if (nearestEntity.getBoundingBox().intersects(myBB)) {
          isSteppedOn = true;
        }
      }
    }

    if (isSteppedOn && !wasSteppedOn) {
      this.level.playSound(null, this.position, SoundEvents.METAL_PRESSURE_PLATE_CLICK_ON, SoundSource.BLOCKS, 4.0f, 0.7f);
      this.steppedOn = true;
      this.updateBlockDisplayBlock();
    } else if (wasSteppedOn && !isSteppedOn) {
      this.level.playSound(null, this.position, SoundEvents.METAL_PRESSURE_PLATE_CLICK_OFF, SoundSource.BLOCKS, 4.0f, 0.5f);
      this.steppedOn = false;
      if (Math.random() < 0.98d) {
        Vec3 xyz = Vec3.atCenterOf(this.position.below());
        this.level.explode(this.blockDisplay, xyz.x, xyz.y, xyz.z, 4f, Level.ExplosionInteraction.BLOCK);
        this.level.explode(this.blockDisplay, xyz.x, xyz.y, xyz.z, 7f, Level.ExplosionInteraction.BLOCK);
        this.level.sendParticles(ParticleTypes.LAVA, false, false, xyz.x, xyz.y, xyz.z, 256, 0.25d, 0.25d, 0.25d, 25d);
        this.blockDisplay.remove(Entity.RemovalReason.DISCARDED);
      } else {
        this.updateBlockDisplayBlock();
      }
    }

  }

  public boolean isRemoved() {
    return this.blockDisplay.isRemoved();
  }

  public static @Nullable Landmine maybeAttachEntity(Entity entity) {
    if (entity.level() instanceof ServerLevel serverLevel && entity instanceof Display.BlockDisplay blockDisplay && entity.entityTags().contains("landmine")) {
      return new Landmine(blockDisplay, serverLevel);
    }
    return null;
  }

}
