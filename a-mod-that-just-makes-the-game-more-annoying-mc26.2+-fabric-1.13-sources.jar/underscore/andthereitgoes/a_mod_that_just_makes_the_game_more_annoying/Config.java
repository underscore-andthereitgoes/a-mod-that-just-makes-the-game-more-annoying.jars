package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.fabricmc.loader.api.FabricLoader;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Predicate;


public final class Config {

  public static final ConfigProperty ALL_ZOMBIES_ARE_BABIES = p("server", "all_zombies_are_babies", false);
  public static final ConfigProperty ALWAYS_SPAWN_PHANTOMS = p("server", "always_spawn_phantoms", false);
  public static final ConfigProperty ANIMALS_STOP_SLEEP = p("server", "animals_stop_sleep", true);
  public static final ConfigProperty ANXIOUS_ENDERMEN = p("server", "anxious_endermen", true);
  public static final ConfigProperty BED_WETTING = p("server", "bed_wetting", true);
  public static final ConfigProperty BEDS_TP_TO_NETHER = p("server", "beds_tp_to_nether", true);
  public static final ConfigProperty BEEHIVES_EXPLODE_NEAR_PLAYERS = p("server", "beehives_explode_near_players", true);
  public static final ConfigProperty BEES_STING_ENDLESSLY = p("server", "bees_sting_endlessly", true);
  public static final ConfigProperty BLOCK_DROPS_RANDOM_ATTRIBUTE_MODIFIERS = p("server", "block_drops_random_attribute_modifiers", true);
  public static final ConfigProperty BROKEN_RECIPES = p("server", "broken_recipes", false);
  public static final ConfigProperty COAL_BURNS_FAST = p("server", "coal_burns_fast", true);
  public static final ConfigProperty DESTROYING_BLOCKS_WITH_HAND_HURTS = p("server", "destroying_blocks_with_hand_hurts", true);
  public static final ConfigProperty DIFFERENT_END_BED_EXPLOSION = p("server", "different_end_bed_explosion", true);
  public static final ConfigProperty DIG_DOWN_LAVA_TROLL = p("server", "dig_down_lava_troll", true);
  public static final ConfigProperty DISABLE_PAUSE = p("*", "disable_pause", false);
  public static final ConfigProperty DO_NOT_SWIM = p("*", "do_not_swim", true);
  public static final ConfigProperty DOORS_ARE_AFRAID_OF_WATER = p("server", "doors_are_afraid_of_water", true);
  public static final ConfigProperty DOORS_CHANGE_RANDOMLY = p("server", "doors_change_randomly", true);
  public static final ConfigProperty DRAGON_EGGS_TELEPORT_FURTHER = p("*", "dragon_eggs_teleport_further", true);
  public static final ConfigProperty ELDER_GUARDIAN_INCREASED_RANGE = p("server", "elder_guardian_increased_range", true);
  public static final ConfigProperty EMERALD_INFLATION = p("server", "emerald_inflation", false);
  public static final ConfigProperty ENDERMEN_RANDOMLY_GET_BOOM = p("server", "endermen_randomly_get_boom", true);
  public static final ConfigProperty ENDERMEN_TELEPORT_A_LOT = p("server", "endermen_teleport_a_lot", false);
  public static final ConfigProperty END_CRYSTALS_REQUIRE_PLAYER_PUNCH = p("server", "end_crystals_require_player_punch", true);
  public static final ConfigProperty END_PORTAL_NEEDS_FRAME = p("server", "end_portal_needs_frame", true);
  public static final ConfigProperty ENVIRONMENTAL_TEMPERATURE_DAMAGE = p("server", "environmental_temperature_damage", false);
  public static final ConfigProperty EVERY_ZOMBIE_IS_A_LEADER = p("server", "every_zombie_is_a_leader", false);
  public static final ConfigProperty FALL_DAMAGE_AT_2_BLOCKS = p("*", "fall_damage_at_2_blocks", true);
  public static final ConfigProperty FALL_THROUGH_LEAVES = p("*", "fall_through_leaves", false);
  public static final ConfigProperty FRAGILE_OBSIDIAN = p("server", "fragile_obsidian", true);
  public static final ConfigProperty FURNACE_COOKING_TIME_X5 = p("server", "furnace_cooking_time_x5", true);
  public static final ConfigProperty FURNACE_EXPONENTIAL_PROGRESS = p("client", "furnace_exponential_progress", true);
  public static final ConfigProperty GOOFY_ENDER_DRAGON = p("client", "goofy_ender_dragon", true);
  public static final ConfigProperty GOOFY_SPIDERS = p("server", "goofy_spiders", true);
  public static final ConfigProperty GRAVEL_AND_STONES_FALL_ON_YOUR_HEAD = p("server", "gravel_and_stones_fall_on_your_head", true);
  public static final ConfigProperty HALVE_DRAGON_DAMAGE = p("server", "halve_dragon_damage", true);
  public static final ConfigProperty INVENTORY_GLASS_PANES_TROLL = p("server", "inventory_glass_panes_troll", true);
  public static final ConfigProperty INVERSE_ABSORPTION = p("*", "inverse_absorption", true);
  public static final ConfigProperty INVISIBLE_CREEPERS = p("client", "invisible_creepers", true);
  public static final ConfigProperty ITEMS_BREAK_RANDOMLY = p("server", "items_break_randomly", true);
  public static final ConfigProperty LESS_COAL_ORE = p("server", "less_coal_ore", true);
  public static final ConfigProperty LOUD_CREEPERS = p("server", "loud_creepers", true);
  public static final ConfigProperty LOWER_STEP_HEIGHT = p("*", "lower_step_height", true);
  public static final ConfigProperty MINING_FATIGUE_UNAFFECTED_BY_MILK = p("server", "mining_fatigue_unaffected_by_milk", false);
  public static final ConfigProperty OFFSET_CROSSHAIR = p("client", "offset_crosshair", true);
  public static final ConfigProperty OFFSET_HUNGER_BAR = p("client", "offset_hunger_bar", true);
  public static final ConfigProperty PHANTOMS_PICK_UP_PLAYERS = p("server", "phantoms_pick_up_players", true);
  public static final ConfigProperty PIGLINS_BLOW_UP = p("server", "piglins_blow_up", true);
  public static final ConfigProperty QUICKGRAVEL = p("server", "quickgravel", true);
  public static final ConfigProperty RANDOMLY_STOP_SNEAKING_IN_NETHER = p("client", "randomly_stop_sneaking_in_nether", true);
  public static final ConfigProperty REALLY_HARD_MODE = p("server", "really_hard_mode", true);
  public static final ConfigProperty REPLACE_END_PLATFORM = p("server", "replace_end_platform", true);
  public static final ConfigProperty REPLACE_END_PORTAL = p("*", "replace_end_portal", true);
  public static final ConfigProperty REPLACE_LAVA_SOLIDIFICATION = p("server", "replace_lava_solidification", true);
  public static final ConfigProperty REQUIRE_8_CRYSTALS_FOR_RESPAWN = p("server", "require_8_crystals_for_respawn", true);
  public static final ConfigProperty REQUIRE_BALANCED_DIET = p("server", "require_balanced_diet", true);
  public static final ConfigProperty SHIELD_BLOCKING_DISABLES = p("server", "shield_blocking_disables", true);
  public static final ConfigProperty SHUFFLE_CHESTS_ON_OPEN = p("server", "shuffle_chests_on_open", true);
  public static final ConfigProperty SLEEP_AFTER_MIDNIGHT = p("server", "sleep_after_midnight", true);
  public static final ConfigProperty SUPER_BOUNCY = p("*", "super_bouncy", true);
  public static final ConfigProperty SWEEPING_DAMAGES_SELF = p("server", "sweeping_damages_self", true);
  public static final ConfigProperty SWEET_BERRY_BUSHES_APPLY_EFFECTS = p("server", "sweet_berry_bushes_apply_effects", true);
  public static final ConfigProperty SWEET_BERRY_BUSHES_SPREAD = p("server", "sweet_berry_bushes_spread", true);
  public static final ConfigProperty TAMING_ANIMALS_EXPLODES = p("server", "taming_animals_explodes", false);
  public static final ConfigProperty TERRIBLE_REPUTATION = p("server", "terrible_reputation", true);
  public static final ConfigProperty THIN_BRIDGES_BREAK = p("server", "thin_bridges_break", true);
  public static final ConfigProperty THIN_ICE = p("server", "thin_ice", true);
  public static final ConfigProperty TTS_GUIDE = p("client", "tts_guide", true);
  public static final ConfigProperty UNCAPPED_VOLUME = p("client", "uncapped_volume", true);
  public static final ConfigProperty VICIOUS_HORSES = p("server", "vicious_horses", true);
  public static final ConfigProperty WITHER_SKELETONS_COMBINE = p("server", "wither_skeletons_combine", true);
  public static final ConfigProperty RARE_ITEMS_FLY_AWAY = p("*", "rare_items_fly_away", true);
  public static final ConfigProperty ORIGIN_DESERT = p("server", "origin_desert", false);
  public static final ConfigProperty SPLASH_POTIONS_EXPLODE = p("server", "spash_potions_explode", true);
  public static final ConfigProperty EXPERIENCE_ORBS_HURT = p("server", "experience_orbs_hurt", true);
  public static final ConfigProperty NO_XP = p("server", "no_xp", true);
  public static final ConfigProperty SKELETON_HOMING_ARROWS = p("server", "skeleton_homing_arrows", true);
  public static final ConfigProperty NO_ENCHANTING_TABLES = p("server", "no_enchanting_tables", true);
  public static final ConfigProperty EXPLODE_ON_PLACE = p("server", "explode_on_place", true);
  public static final ConfigProperty ANNOYING_TRAPPED_CHESTS = p("server", "annoying_trapped_chests", true);
  public static final ConfigProperty FAST_GHASTS = p("server", "fast_ghasts", true);
  public static final ConfigProperty FURNACE_TOUCH_DAMAGE = p("server", "furnace_touch_damage", true);
  public static final ConfigProperty LAVA_SPREADS_LAVA = p("server", "lava_spreads_lava", false);
  public static final ConfigProperty EDGING_TNT = p("server", "edging_tnt", true);
  public static final ConfigProperty FALL_HEART_ATTACKS = p("server", "fall_heart_attacks", false);
  public static final ConfigProperty OVERCOOKING = p("server", "overcooking", true);
  public static final ConfigProperty FUEL_ALWAYS_BURNS = p("server", "fuel_always_burns", true);
  public static final ConfigProperty HOLDING_LAVA_HURTS = p("server", "holding_lava_hurts", true);
  public static final ConfigProperty ENCHANTMENTS_DISAPPEAR = p("server", "enchantments_disappear", true);
  public static final ConfigProperty LAVA_BLOWS_UP_FURNACES = p("server", "lava_blows_up_furnaces", true);
  public static final ConfigProperty LACTOSE_INTOLERANCE = p("server", "lactose_intolerance", true);
  public static final ConfigProperty SHORT_ENDERMAN_HITBOX = p("*", "short_enderman_hitbox", true);
  public static final ConfigProperty ENDERMEN_SOCIAL_ANXIETY = p("server", "enderman_social_anxiety", true);
  public static final ConfigProperty ENDERMEN_DONT_FREEZE = p("server", "endermen_dont_freeze", true);
  public static final ConfigProperty ENDERMEN_HOLD_ANYTHING = p("server", "endermen_hold_anything", true);
  public static final ConfigProperty ENDERMEN_CANNOT_HOLD_WITHER_IMMUNE = p("server", "endermen_cannot_hold_wither_immune", true);
  public static final ConfigProperty SLOW_ARMOUR = p("server", "slow_armour", true);
  public static final ConfigProperty ALTITUDE_TEMPERATURE_DAMAGE = p("server", "altitude_temperature_damage", true);
  public static final ConfigProperty EXPLOSIVE_RABBITS = p("server", "explosive_rabbits", true);
  public static final ConfigProperty NORMAL_RAILS_ARE_POWERED_OFF = p("server", "normal_rails_are_powered_off", true);
  public static final ConfigProperty ENDERMEN_UNAFFECTED_BY_WATER = p("server", "endermen_unaffected_by_water", true);
  public static final ConfigProperty BATS_TARGET_EYES = p("server", "bats_target_eyes", true);
  public static final ConfigProperty BEDROCK_OFFHAND_OR_LIGHTNING = p("server", "bedrock_offhand_or_lightning", true);
  public static final ConfigProperty ITEMS_DIE_NEAR_PLAYERS = p("server", "items_die_near_players", true);
//  public static final ConfigProperty SHY_FURNACES = p("server", "shy_furnaces", true);
  public static final ConfigProperty RAILS_SPAWN_FURNACE_MINECARTS = p("server", "rails_spawn_furnace_minecraft", true);
  public static final ConfigProperty INVENTORY_WATER_BUCKET_SPILLING = p("server", "inventory_water_bucket_spilling", true);
  public static final ConfigProperty FURNACE_MINECARTS_USELESS = p("server", "furnace_minecarts_useless", true);
  public static final ConfigProperty ENDERMEN_TARGET_IMPORTANT_BLOCKS = p("server", "endermen_target_important_blocks", true);
  public static final ConfigProperty LANDMINES = p("server", "landmines", true);
  public static final ConfigProperty MOSTLY_REMOVE_SQUIDS = p("server", "mostly_remove_squids", false);
  public static final ConfigProperty TALL_LANDS = p("server", "tall_lands", false);
  public static final ConfigProperty REMOVE_TOOLTIP_BACKGROUNDS = p("client", "remove_tooltip_backgrounds", true);
  public static final ConfigProperty NO_SLOT_HIGHLIGHT = p("client", "no_slot_highlight", false);
  public static final ConfigProperty OFFSET_SLOT_HIGHLIGHT = p("client", "offset_slot_highlight", true);
  public static final ConfigProperty WILD_TAMED_ANIMALS = p("server", "wild_tamed_animals", true);
  public static final ConfigProperty LLAMA_SPIT_LAUNCH = p("server", "llama_spit_launch", true);
  public static final ConfigProperty IRON_GOLEM_EXTENDED_REACH = p("server", "iron_golem_extended_reach", true);
  public static final ConfigProperty IRON_GOLEM_SPACE_PROGRAM = p("server", "iron_golem_space_program", true);
  public static final ConfigProperty NERVOUS_HORSES = p("server", "nervous_horses", true);
  public static final ConfigProperty SHULKER_MACHINE_GUNS = p("server", "shulker_machine_guns", true);
  public static final ConfigProperty SKELETON_SHOTGUNS = p("server", "skeleton_shotguns", false);
  public static final ConfigProperty FIFTY_SKELETON_HORSES = p("server", "fifty_skeleton_horses", true);
  public static final ConfigProperty CHICKENS_V2 = p("server", "chickens_v2", true);
  public static final ConfigProperty LAVA_FLOWS_FAST = p("server", "lava_flows_fast", true);
  public static final ConfigProperty FLYING_SQUIDS = p("server", "flying_squids", true);
  public static final ConfigProperty NEUTRAL_LEVITATION = p("*", "neutral_levitation", true);
  public static final ConfigProperty CREEPERS_IGNORE_CATS = p("server", "creepers_ignore_cats", true);
  public static final ConfigProperty FURNACES_LITERALLY = p("server", "furnaces_literally", true);
  public static final ConfigProperty FLETCHING_TABLES_SHOOT = p("server", "fletching_tables_shoot", true);
//  public static final ConfigProperty MOBS_DRIVE_BOATS = p("server", "mobs_drive_boats", true);
  public static final ConfigProperty SHULKERS_SHOOT_CLOSED = p("server", "shulkers_shoot_closed", true);
  public static final ConfigProperty UNBREAKING_ELYTRA_FLIES_SLOWER = p("*", "unbreaking_elytra_flies_slower", true);
//  public static final ConfigProperty END_SOUL_SAND_AND_BASALT_DELTAS = p("server", "end_soul_sand_and_basalt_deltas", true);
  public static final ConfigProperty ENDER_PEARLS_MOVE_SLOWLY = p("*", "ender_pearls_move_slowly", true);
  public static final ConfigProperty SKELETON_DODGING = p("server", "skeleton_dodging", true);
  public static final ConfigProperty HISSBINES = p("server", "hissbines", true);
//  public static final ConfigProperty INCREASED_PLAYER_HEIGHT = p("*", "increased_player_height", false);
  public static final ConfigProperty MONSTERS_WITH_HELMETS = p("server", "monsters_with_helmets", true);
  public static final ConfigProperty SMALLER_BABY_ZOMBIES = p("*", "small_baby_zombies", false);
  public static final ConfigProperty BLAZE_MACHINE_GUNS = p("server", "blaze_machine_guns", true);
  public static final ConfigProperty NETHERITE_WITHER_SKELETONS = p("server", "netherite_wither_skeletons", false);
  public static final ConfigProperty SHORT_WITHER_SKELETON_HITBOX = p("*", "short_wither_skeleton_hitbox", true);
  public static final ConfigProperty MOBS_DONT_DAMAGE_HELMETS = p("server", "mobs_dont_damage_helmets", true);
  public static final ConfigProperty MOB_ARMOR_BINDING_CURSE = p("server", "mob_armor_binding_curse", true);
  public static final ConfigProperty NO_OFFHAND_KEY = p("client", "no_offhand_key", false);
  public static final ConfigProperty MORE_LIGHTNING = p("server", "more_lightning", true);
  public static final ConfigProperty MORE_THUNDERSTORMS = p("server", "more_thunderstorms", true);
  public static final ConfigProperty NAUSEA_INVERTED_MOVEMENT = p("client", "nausea_inverted_movement", true);

  private static @NotNull ConfigProperty p(final String type, final String name, final boolean defaultValue) {
    return new ConfigProperty(type, name, defaultValue);
  }

  private static void loadConfigFile(File configFile) throws RuntimeException, IOException {
    if (configFile.exists()) {

      try {

        FileReader fileReader = new FileReader(configFile);
        JsonObject jsonObject = JsonParser.parseReader(fileReader).getAsJsonObject();
        fileReader.close();

        ConfigProperty.allProperties.forEach(property -> property.setFrom(jsonObject));

      } catch (Exception e) {
        throw new RuntimeException("AMTJMTGMA config failed to load.", e);
      }

    } else {

      LogUtils.getLogger().info("Creating new AMTJMTGMA config");

      configFile.getParentFile().mkdirs();
      configFile.createNewFile();

    }

    JsonObject configObject = new JsonObject();
    ConfigProperty.allProperties.forEach(property -> property.storeTo(configObject));

    FileWriter writer = new FileWriter(configFile);
    writer.write(new GsonBuilder().setPrettyPrinting().create().toJson(configObject));
    writer.close();

  }

  public static void loadConfig() throws RuntimeException, IOException {
    LogUtils.getLogger().info("Loading AMTJMTGMA config");
    loadConfigFile(FabricLoader.getInstance().getConfigDir().resolve("a_mod_that_just_makes_the_game_more_annoying.json").toFile());
  }

  public static void forEachProperty(Consumer<ConfigProperty> consumer, Predicate<ConfigProperty> predicate) {
    ConfigProperty.allProperties.stream().filter(predicate).forEach(consumer);
  }

  public static void forEachProperty(Consumer<ConfigProperty> consumer) {
    ConfigProperty.allProperties.forEach(consumer);
  }

  public static final class ConfigProperty implements BooleanSupplier {
    private static final List<ConfigProperty> allProperties = new ArrayList<>();

    public final String type;
    public final String name;
    private boolean value;

    private ConfigProperty(String type, String name, boolean defaultValue) {
      this.type = type;
      this.name = name;
      this.value = defaultValue;
      allProperties.add(this);
    }

    public boolean get() {
      return this.value;
    }

    public void set(Boolean newValue) {
      this.value = newValue;
    }

    void setFrom(JsonObject object) {
      @NotNull JsonObject subobject = new JsonObject();
      try {
        subobject = Objects.requireNonNull(object.getAsJsonObject(this.type));
      } catch (Exception e) {
        if (!object.has(this.type)) {
          throw new RuntimeException("AMTJMTGMA config error: Missing property " + this.type + " (object)");
        }
      }
      if (!subobject.has(this.name)) {
        LogUtils.getLogger().warn("AMTJMTGMA config warning: Missing property {}/{} (using default value {})", this.type, this.name, this.value);
        return;
      }
      try {
        this.value = subobject.get(this.name).getAsBoolean();
      } catch (Exception e) {
        throw new RuntimeException("AMTJMTGMA config error: Invalid type for property " + this.type + "/" + this.name + " (should be boolean)");
      }
    }

    void storeTo(JsonObject object) {
      if (!object.has(this.type)) object.add(this.type, new JsonObject());
      object.getAsJsonObject(this.type).addProperty(this.name, this.value);
    }

    @Override
    public boolean equals(Object obj) {
      if (obj instanceof ConfigProperty) {
        return this.value == ((ConfigProperty)obj).value;
      } else if (obj instanceof Boolean) {
        return this.value == (boolean)obj;
      } else return super.equals(obj);
    }

    @Override
    public boolean getAsBoolean() {
      return this.get();
    }
  }
}
