package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.flying_squids;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.AgeableWaterCreature;
import net.minecraft.world.entity.animal.squid.Squid;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Squid.class)
public abstract class SquidMixin extends AgeableWaterCreature {

  protected SquidMixin(EntityType<? extends AgeableWaterCreature> type, Level level) {
    super(type, level);
  }

//  @Inject(method = "aiStep", at = @At("HEAD"))
//  private void preAiStep(CallbackInfo ci) {
//    if (Config.FLYING_SQUIDS.get()) this.wasTouchingWater = false;
//  }

  @Redirect(method = "aiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/animal/squid/Squid;isInWater()Z"))
  private boolean replaceIsInWater(Squid instance) {
    if (Config.FLYING_SQUIDS.get()) return true;
    else return instance.isInWater();
  }

  @Override
  protected boolean shouldTakeDrowningDamage() {
    if (Config.FLYING_SQUIDS.get()) return false;
    return super.shouldTakeDrowningDamage();
  }
}
