package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_shy_furnaces;

import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin {

  /*
  @Unique
  private static final TargetingConditions PLAYER_TARGETER = TargetingConditions.forNonCombat();

  @Unique
  private static final double MAX_DISTANCE = 64d * 64d;
  @Unique
  private static final double CLOSE_DISTANCE_SQR = 3d * 3d;

  @Definition(id = "entity", local = @Local(type = AbstractFurnaceBlockEntity.class, name = "entity", argsOnly = true))
  @Definition(id = "litTimeRemaining", field = "Lnet/minecraft/world/level/block/entity/AbstractFurnaceBlockEntity;litTimeRemaining:I")
  @Expression("entity.litTimeRemaining = ?")
  @ModifyVariable(method = "serverTick", at = @At(value = "MIXINEXTRAS:EXPRESSION"), name = "newLitTime")
  private static int replaceIsEmpty(
      int newLitTime,
      @Local(name = "entity", argsOnly = true) AbstractFurnaceBlockEntity entity,
      @Local(name = "level", argsOnly = true) ServerLevel level,
      @Local(name = "pos", argsOnly = true) BlockPos pos,
      @Local(name = "state", argsOnly = true) BlockState state
  ) {
    LogUtils.getLogger().info("WORKING");
    LogUtils.getLogger().info("original: {}", newLitTime);
    if (Config.SHY_FURNACES.get()) {
      Vec3 sourcePos = Vec3.atCenterOf(pos);
      Player tooClosePlayer = level.getNearestPlayer(PLAYER_TARGETER, sourcePos.x, sourcePos.y, sourcePos.z);
      LogUtils.getLogger().info("too close player: {}", tooClosePlayer);
      if (tooClosePlayer != null && tooClosePlayer.getEyePosition().distanceToSqr(sourcePos) <= CLOSE_DISTANCE_SQR) {
        entity.litTimeRemaining = 0;
        return 0;
      }
      Vec3 furnaceFacingAngle = state.getValue(FurnaceBlock.FACING).getUnitVec3();
      Player lookingPlayer = level.getNearestPlayer(sourcePos.x, sourcePos.y, sourcePos.z, MAX_DISTANCE, player -> {
        LivingEntity livingEntity = player.asLivingEntity();
        if (livingEntity == null) return false;
        if (PLAYER_TARGETER.test(level, null, livingEntity)) return false;
        Vec3 lookDir = player.getLookAngle();
        LogUtils.getLogger().info("look dir: {} | dot: {} | clip: {}", lookDir, lookDir.dot(furnaceFacingAngle), level.clip(new ClipContext(player.getEyePosition(), sourcePos.subtract(lookDir.scale(2d)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty())).getType());
        return lookDir.dot(furnaceFacingAngle) < -0.5d && level.clip(new ClipContext(player.getEyePosition(), sourcePos.subtract(lookDir.scale(2d)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty())).getType() == HitResult.Type.MISS;
      });
      LogUtils.getLogger().info("looking player: {}", lookingPlayer);
      if (lookingPlayer != null) {
        entity.litTimeRemaining = 0;
        return 0;
      }
    }
    return newLitTime;
  }
  */

}
