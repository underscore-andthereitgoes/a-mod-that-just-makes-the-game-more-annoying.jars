package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin._global.server;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.io.IOException;


@Mixin(MinecraftServer.class)
@Environment(EnvType.SERVER)
public abstract class MinecraftServerMixin {

  @Inject(
      method = "loadLevel",
      at = @At(
          value="INVOKE",
          target="Lnet/minecraft/server/MinecraftServer;createLevels()V"
      )
  )
  public void loadConfigFile(CallbackInfo ci) throws RuntimeException, IOException {
    Config.loadConfig();
  }

}
