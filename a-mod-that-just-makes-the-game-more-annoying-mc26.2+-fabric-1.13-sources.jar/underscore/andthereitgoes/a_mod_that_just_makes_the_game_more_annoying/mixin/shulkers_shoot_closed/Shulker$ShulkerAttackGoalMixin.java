package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.shulkers_shoot_closed;

import net.minecraft.world.entity.monster.Shulker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Shulker.ShulkerAttackGoal.class)
public abstract class Shulker$ShulkerAttackGoalMixin {

  @ModifyArg(method = "start", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/monster/Shulker;setRawPeekAmount(I)V"))
  private int changePeekAmount(int amount) {
    if (Config.SHULKERS_SHOOT_CLOSED.get()) return 0;
    return amount;
  }

}
