package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.really_hard_mode;

import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(DifficultyInstance.class)
public abstract class DifficultyInstanceMixin {

  @Inject(method = "calculateDifficulty", at = @At("HEAD"), cancellable = true)
  private void calculateDifficulty(Difficulty base, long totalGameTime, long localGameTime, float moonBrightness, CallbackInfoReturnable<Float> cir) {
    if (!Config.REALLY_HARD_MODE.get()) return;
    if (base == Difficulty.PEACEFUL) {
      cir.setReturnValue(0f);
    } else {
//      boolean isHard = base == Difficulty.HARD;
//      float scale = 0.75f;
//      float globalScale = Mth.clamp(((float)totalGameTime + -72000.0F) / 1440000.0F, 0.0F, 1.0F) * 0.25F;
//      scale += globalScale;
//      float localScale = 0.0f;
//      localScale += Mth.clamp((float)localGameTime / 3600000.0F, 0.0F, 1.0F) * (isHard ? 1.0F : 0.75F);
//      localScale += Mth.clamp(moonBrightness * 0.25F, 0.0F, globalScale);
//      if (base == Difficulty.EASY) {
//        localScale *= 0.5F;
//      }

//      scale += localScale;
//      return (float)base.getId() * scale;
      cir.setReturnValue(10f);
    }
  }

}
