package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.mining_fatigue_unaffected_by_milk;

import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.consume_effects.ClearAllStatusEffectsConsumeEffect;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ClearAllStatusEffectsConsumeEffect.class)
public abstract class ClearAllStatusEffectsConsumeEffectMixin {

  @Inject(method = "apply", at = @At("HEAD"), cancellable = true)
  private void reapply(Level level, ItemStack stack, LivingEntity user, CallbackInfoReturnable<Boolean> cir) {
    if (Config.MINING_FATIGUE_UNAFFECTED_BY_MILK.get()) {
      user.getActiveEffects().forEach(effectInstance -> {
        if (!effectInstance.is(MobEffects.MINING_FATIGUE)) user.removeEffect(effectInstance.getEffect());
      });
      cir.setReturnValue(true);
      cir.cancel();
    }
  }

}
