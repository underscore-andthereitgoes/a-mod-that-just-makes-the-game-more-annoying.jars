package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.emerald_inflation;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.TradeCost;
import net.minecraft.world.level.storage.loot.LootContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(TradeCost.class)
public abstract class TradeCostMixin {
  @Inject(method = "toItemCost", at = @At("TAIL"), cancellable=true)
  private void toItemCostTAIL(LootContext lootContext, int additionalCost, CallbackInfoReturnable<ItemCost> cir) {
    if (!Config.EMERALD_INFLATION.get()) return;
    ItemCost originalCost = cir.getReturnValue();
    if (originalCost.itemStack().is(Items.EMERALD) && originalCost.count() < 64) {
      cir.setReturnValue(new ItemCost(originalCost.item(), 64, originalCost.components()));
    }
  }
}
