package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.terrible_reputation;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.world.entity.ai.gossip.GossipContainer;
import net.minecraft.world.entity.ai.gossip.GossipType;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(GossipContainer.EntityGossips.class)
public abstract class GossipContainer$EntityGossipsMixin {

  @Shadow
  @Final
  private Object2IntMap<GossipType> entries;

  @Shadow
  public abstract void remove(GossipType type);

  @Inject(method = "makeSureValueIsntTooLowOrTooHigh", at = @At("HEAD"), cancellable = true)
  private void makeSureValueIsntTooLowOrTooHigh(GossipType type, CallbackInfo ci) {
    if (!Config.TERRIBLE_REPUTATION.get()) return;
    int value = this.entries.getInt(type);
    int max = type.max;
    if (type == GossipType.MAJOR_NEGATIVE || type == GossipType.MINOR_NEGATIVE) max = 1000;
    else max = 2;
    if (value > max) {
      this.entries.put(type, max);
      value = max;
    }
    if (value < 2) {
      this.remove(type);
    }
    ci.cancel();
  }

}
