package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.halve_dragon_damage;

import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderDragon.class)
public abstract class EnderDragonMixin {

  @ModifyVariable(
      method = "hurt(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/boss/enderdragon/EnderDragonPart;Lnet/minecraft/world/damagesource/DamageSource;F)Z",
      at = @At("HEAD"),
      argsOnly = true,
      name = "damage"
  )
  private float decreaseDamage(float damage) {
    if (!Config.HALVE_DRAGON_DAMAGE.get()) return damage;
    return damage / 2.0f;
  }

}
