package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_mobs_drive_boats;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.VehicleEntity;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(AbstractBoat.class)
public abstract class AbstractBoatMixin extends VehicleEntity {

  public AbstractBoatMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  /*
  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (Config.MOBS_DRIVE_BOATS.get() && !this.level().isClientSide()) {
      AbstractBoat boat = (AbstractBoat)(Object)this;
      LivingEntity controller = boat.getControllingPassenger();
      if (controller instanceof Mob mob) {
        LogUtils.getLogger().info("controller: {}", controller);
        Path path = mob.getNavigation().getPath();
        LogUtils.getLogger().info("path: {}", path);
        if (path != null) {
          BlockPos nextNodePos = path.getNextNodePos();
          LogUtils.getLogger().info("node: {}", nextNodePos);
          Vec3 nextNodeOffset = Vec3.atBottomCenterOf(nextNodePos).subtract(boat.position());
          float targetYaw = nextNodeOffset.rotation().y;
          float yaw = boat.getRotationVector().y;
          float yawOffset = (targetYaw - yaw + 540f) % 360f - 180f;
          boat.deltaRotation += yawOffset / 20f;
          if (Math.abs(yawOffset) < 15f) {
            float acceleration = 0.1f;
            boat.setDeltaMovement(boat.getDeltaMovement().add(Mth.sin(-boat.getYRot() * ((float)Math.PI / 180F)) * acceleration, 0.0F, Mth.cos(boat.getYRot() * ((float)Math.PI / 180F)) * acceleration));
          }
        }
      }
    }
  }
   */

}
