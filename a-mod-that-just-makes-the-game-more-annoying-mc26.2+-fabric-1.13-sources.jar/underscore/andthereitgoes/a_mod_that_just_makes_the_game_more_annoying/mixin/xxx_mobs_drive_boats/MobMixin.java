package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.xxx_mobs_drive_boats;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Mob.class)
public class MobMixin {

  /*
  @Definition(id = "getVehicle", method = "Lnet/minecraft/world/entity/Mob;getVehicle()Lnet/minecraft/world/entity/Entity;")
  @Expression("this.getVehicle()")
  @ModifyExpressionValue(method = "updateControlFlags", at = @At("MIXINEXTRAS:EXPRESSION"))
  private Entity modifyGetVehicleBoatCheck(Entity original) {
    if (Config.MOBS_DRIVE_BOATS.get()) return null;
    return original;
  }
   */

}
