package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.fall_through_leaves;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(LeavesBlock.class)
public abstract class LeavesBlockMixin extends Block {
  public LeavesBlockMixin(Properties properties) {
    super(properties);
  }

  @Override
  public @NonNull VoxelShape getCollisionShape(final @NonNull BlockState state, final @NonNull BlockGetter level, final @NonNull BlockPos pos, final @NonNull CollisionContext context) {
    if (!Config.FALL_THROUGH_LEAVES.get()) return super.getCollisionShape(state, level, pos, context);
    return Shapes.empty();
  }

  @Override
  protected @NonNull VoxelShape getOcclusionShape(@NonNull BlockState state) {
    if (!Config.FALL_THROUGH_LEAVES.get()) return super.getOcclusionShape(state);
    return Shapes.block();
  }

  @Override
  protected void entityInside(final @NonNull BlockState state, final @NonNull Level level, final @NonNull BlockPos pos, final @NonNull Entity entity, final @NonNull InsideBlockEffectApplier effectApplier, final boolean isPrecise) {
    if (!Config.FALL_THROUGH_LEAVES.get()) {
      super.entityInside(state, level, pos, entity, effectApplier, isPrecise);
      return;
    }
    if (entity.getType() == EntityTypes.BEE) return;
    Vec3 speedMultiplier = new Vec3(0.25F, 0.05F, 0.25F);
    if (entity instanceof LivingEntity livingEntity) {
      if (livingEntity.hasEffect(MobEffects.WEAVING)) {
        speedMultiplier = new Vec3(0.5F, 0.25F, 0.5F);
      }
    }
    entity.makeStuckInBlock(state, speedMultiplier);
    if (level instanceof ServerLevel serverLevel) {
      Vec3 movement = entity.isClientAuthoritative() ? entity.getKnownMovement() : entity.oldPosition().subtract(entity.position());
      if (movement.horizontalDistanceSqr() > 0.0d) {
        double xs = Math.abs(movement.x());
        double ys = Math.abs(movement.y());
        double zs = Math.abs(movement.z());
        if (xs >= 0.003d || ys >= 0.003d || zs >= 0.003d) {
          entity.hurtServer(serverLevel, level.damageSources().cactus(), 1.0F);
        }
      }
    }
  }
}
