package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.lower_step_height;

import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @Inject(method = "createAttributes", at = @At("TAIL"))
  private static void modifyCreatedAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (Config.LOWER_STEP_HEIGHT.get()) cir.getReturnValue().add(Attributes.STEP_HEIGHT, 0.4f);
  }

}
