package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.furnace_touch_damage;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.FurnaceMenu;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract boolean hurtServer(ServerLevel level, DamageSource source, float damage);

  @Shadow
  public abstract @NonNull ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.FURNACE_TOUCH_DAMAGE.get()) {
      if (this.containerMenu instanceof FurnaceMenu furnaceMenu) {
        ServerLevel level = this.level();
        if (furnaceMenu.isLit()) this.hurtServer(level, level.damageSources().onFire(), 1.0f);
      }
    }
  }
}
