package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockBehaviour$BlockStateBaseMixin {
  @Inject(method = "getDestroySpeed", at = @At("TAIL"), cancellable = true)
  private void getDestroySpeedTAIL(BlockGetter level, BlockPos pos, CallbackInfoReturnable<Float> cir) {
    if (!Config.REPLACE_END_PORTAL.get()) return;
    if (level.getBlockState(pos).is(Blocks.END_PORTAL_FRAME)) {
      cir.setReturnValue(10.0f);
      cir.cancel();
    }
  }
}
