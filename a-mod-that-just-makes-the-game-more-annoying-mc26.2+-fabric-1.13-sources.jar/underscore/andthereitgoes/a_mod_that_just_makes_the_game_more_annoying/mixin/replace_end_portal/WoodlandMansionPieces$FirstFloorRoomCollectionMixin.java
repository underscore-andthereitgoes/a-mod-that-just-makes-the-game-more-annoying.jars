package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.structure.structures.WoodlandMansionPieces;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(WoodlandMansionPieces.FirstFloorRoomCollection.class)
public abstract class WoodlandMansionPieces$FirstFloorRoomCollectionMixin {

  @Shadow
  public abstract String get1x2Secret(RandomSource random);

  @Inject(method = "get1x2FrontEntrance", at = @At("HEAD"), cancellable = true)
  private void get1x2FrontEntrance_secretChance(RandomSource random, boolean isStairsRoom, CallbackInfoReturnable<String> cir) {
    if (Config.REPLACE_END_PORTAL.get()) {
      if (random.nextDouble() <= 0.05) cir.setReturnValue(this.get1x2Secret(random));
    }
  }

  @Inject(method = "get1x2SideEntrance", at = @At("HEAD"), cancellable = true)
  private void get1x2SideEntrance_secretChance(RandomSource random, boolean isStairsRoom, CallbackInfoReturnable<String> cir) {
    if (Config.REPLACE_END_PORTAL.get()) {
      if (random.nextDouble() <= 0.05) cir.setReturnValue(this.get1x2Secret(random));
    }
  }

}
