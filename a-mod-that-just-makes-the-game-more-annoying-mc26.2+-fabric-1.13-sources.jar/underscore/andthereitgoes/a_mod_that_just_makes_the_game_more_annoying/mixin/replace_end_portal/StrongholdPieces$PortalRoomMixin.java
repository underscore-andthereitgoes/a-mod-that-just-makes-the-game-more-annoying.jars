package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.TestBlockMode;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.structures.StrongholdPieces;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(StrongholdPieces.PortalRoom.class)
public abstract class StrongholdPieces$PortalRoomMixin extends StrongholdPieces.StrongholdPiece {
  @Shadow
  private boolean hasPlacedSpawner;

  public StrongholdPieces$PortalRoomMixin(StructurePieceType type, CompoundTag tag) {
    super(type, tag);
  }

  @Unique
  private static final BlockSelector portalRoomFloorSelector = new BlockSelector() {
    @Override
    public void next(@NonNull RandomSource random, int worldX, int worldY, int worldZ, boolean isEdge) {
      if (isEdge) {
        BlockState blockState = Blocks.TEST_BLOCK.defaultBlockState();
        blockState = blockState.setValue(BlockStateProperties.TEST_BLOCK_MODE, TestBlockMode.FAIL);
        this.next = blockState;
      } else {
        this.next = Blocks.CAVE_AIR.defaultBlockState();
      }
    }
  };
  @Unique
  private static final BlockSelector portalRoomPrismarine = new BlockSelector() {
    @Override
    public void next(@NonNull RandomSource random, int worldX, int worldY, int worldZ, boolean isEdge) {
      if (isEdge) {
        this.next = Blocks.PRISMARINE.defaultBlockState();
      } else {
        this.next = Blocks.CAVE_AIR.defaultBlockState();
      }
    }
  };

  @Inject(method = "postProcess", at = @At("HEAD"), cancellable = true)
  public void postProcess(WorldGenLevel level, StructureManager structureManager, ChunkGenerator generator, RandomSource random, BoundingBox chunkBB, ChunkPos chunkPos, BlockPos referencePos, CallbackInfo ci) {
    if (!Config.REPLACE_END_PORTAL.get()) return;
    this.generateBox(level, chunkBB, 0, 0, 0, 10, 7, 15, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 3, 1, 0, 5, 3, 0, false, random, new BlockSelector() {
      @Override
      public void next(RandomSource random, int worldX, int worldY, int worldZ, boolean isEdge) {
        this.next = Blocks.CAVE_AIR.defaultBlockState();
      }
    });
//    this.generateSmallDoor(level, random, chunkBB, StrongholdPieces.StrongholdPiece.SmallDoorType.GRATES, 4, 1, 0);
    this.generateBox(level, chunkBB, 1, 6, 1, 1, 6, 14, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 9, 6, 1, 9, 6, 14, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 2, 6, 1, 8, 6, 2, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 2, 6, 14, 8, 6, 14, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 1, 1, 1, 2, 1, 4, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 8, 1, 1, 9, 1, 4, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 1, 1, 1, 1, 1, 3, Blocks.SLIME_BLOCK.defaultBlockState(), Blocks.SLIME_BLOCK.defaultBlockState(), false);
    this.generateBox(level, chunkBB, 9, 1, 1, 9, 1, 3, Blocks.SLIME_BLOCK.defaultBlockState(), Blocks.SLIME_BLOCK.defaultBlockState(), false);
    this.generateBox(level, chunkBB, 3, 1, 8, 7, 1, 12, false, random, portalRoomFloorSelector);
    this.generateBox(level, chunkBB, 4, 1, 9, 6, 1, 11, Blocks.SLIME_BLOCK.defaultBlockState(), Blocks.SLIME_BLOCK.defaultBlockState(), false);
    BlockState nsBars = Blocks.STAINED_GLASS_PANE.purple().defaultBlockState().setValue(StainedGlassPaneBlock.NORTH, true).setValue(StainedGlassPaneBlock.SOUTH, true);
    BlockState weBars = Blocks.STAINED_GLASS_PANE.purple().defaultBlockState().setValue(StainedGlassPaneBlock.WEST, true).setValue(StainedGlassPaneBlock.EAST, true);

    for(int z = 3; z < 14; z += 2) {
      this.generateBox(level, chunkBB, 0, 3, z, 0, 4, z, nsBars, nsBars, false);
      this.generateBox(level, chunkBB, 10, 3, z, 10, 4, z, nsBars, nsBars, false);
    }

    for(int x = 2; x < 9; x += 2) {
      this.generateBox(level, chunkBB, x, 3, 15, x, 4, 15, weBars, weBars, false);
    }

    BlockState stairsState = Blocks.PRISMARINE_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.NORTH);
    this.generateBox(level, chunkBB, 4, 1, 5, 6, 1, 7, false, random, portalRoomPrismarine);
    this.generateBox(level, chunkBB, 4, 2, 6, 6, 2, 7, false, random, portalRoomPrismarine);
    this.generateBox(level, chunkBB, 4, 3, 7, 6, 3, 7, false, random, portalRoomPrismarine);

    for(int x = 4; x <= 6; ++x) {
      this.placeBlock(level, stairsState, x, 1, 4, chunkBB);
      this.placeBlock(level, stairsState, x, 2, 5, chunkBB);
      this.placeBlock(level, stairsState, x, 3, 6, chunkBB);
    }

    Block newFrameBlock = Blocks.WOOL.cyan();
    BlockState northFrame = newFrameBlock.defaultBlockState();//.setValue(EndPortalFrameBlock.FACING, Direction.NORTH);
    BlockState southFrame = newFrameBlock.defaultBlockState();//.setValue(EndPortalFrameBlock.FACING, Direction.SOUTH);
    BlockState eastFrame = newFrameBlock.defaultBlockState();//.setValue(EndPortalFrameBlock.FACING, Direction.EAST);
    BlockState westFrame = newFrameBlock.defaultBlockState();//.setValue(EndPortalFrameBlock.FACING, Direction.WEST);
    /*
    boolean allEyes = true;
    boolean[] eyes = new boolean[12];

    for(int i = 0; i < eyes.length; ++i) {
      eyes[i] = random.nextFloat() > 0.9F;
      allEyes &= eyes[i];
    }
     */

    this.placeBlock(level, northFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[0])*/, 4, 3, 8, chunkBB);
    this.placeBlock(level, northFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[1])*/, 5, 3, 8, chunkBB);
    this.placeBlock(level, northFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[2])*/, 6, 3, 8, chunkBB);
    this.placeBlock(level, southFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[3])*/, 4, 3, 12, chunkBB);
    this.placeBlock(level, southFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[4])*/, 5, 3, 12, chunkBB);
    this.placeBlock(level, southFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[5])*/, 6, 3, 12, chunkBB);
    this.placeBlock(level, eastFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[6])*/, 3, 3, 9, chunkBB);
    this.placeBlock(level, eastFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[7])*/, 3, 3, 10, chunkBB);
    this.placeBlock(level, eastFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[8])*/, 3, 3, 11, chunkBB);
    this.placeBlock(level, westFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[9])*/, 7, 3, 9, chunkBB);
    this.placeBlock(level, westFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[10])*/, 7, 3, 10, chunkBB);
    this.placeBlock(level, westFrame/*.setValue(EndPortalFrameBlock.HAS_EYE, eyes[11])*/, 7, 3, 11, chunkBB);
    /*
    if (allEyes) {
      BlockState portal = Blocks.END_PORTAL.defaultBlockState();
      this.placeBlock(level, portal, 4, 3, 9, chunkBB);
      this.placeBlock(level, portal, 5, 3, 9, chunkBB);
      this.placeBlock(level, portal, 6, 3, 9, chunkBB);
      this.placeBlock(level, portal, 4, 3, 10, chunkBB);
      this.placeBlock(level, portal, 5, 3, 10, chunkBB);
      this.placeBlock(level, portal, 6, 3, 10, chunkBB);
      this.placeBlock(level, portal, 4, 3, 11, chunkBB);
      this.placeBlock(level, portal, 5, 3, 11, chunkBB);
      this.placeBlock(level, portal, 6, 3, 11, chunkBB);
    }
     */

    if (!this.hasPlacedSpawner) {
      BlockPos pos = this.getWorldPos(5, 3, 6);
      if (chunkBB.isInside(pos)) {
        this.hasPlacedSpawner = true;
        level.setBlock(pos, Blocks.SPAWNER.defaultBlockState(), 2);
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof SpawnerBlockEntity spawner) {
          spawner.setEntityId(EntityTypes.WITHER_SKELETON, random);
        }
      }
    }

    ci.cancel();
  }

}
