package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ProblemReporter;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Unit;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTypes;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.storage.TagValueInput;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.List;
import java.util.Map;


@Mixin(StructureTemplate.class)
public abstract class StructureTemplateMixin {

  @Shadow
  @Final
  private static Logger LOGGER;

  @Inject(
      method = "placeInWorld",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/level/block/entity/BlockEntity;loadWithComponents(Lnet/minecraft/world/level/storage/ValueInput;)V",
          shift = At.Shift.AFTER
      )
  )
  private void placeInWorld_loadWithComponents_after(ServerLevelAccessor level, BlockPos position, BlockPos referencePos, StructurePlaceSettings settings, RandomSource random, int updateMode, CallbackInfoReturnable<Boolean> cir, @Local(name = "blockInfo") StructureTemplate.StructureBlockInfo blockInfo, @Local(name = "blockEntity") BlockEntity blockEntity) {
    if (!Config.REPLACE_END_PORTAL.get()) return;
    if (blockEntity.is(BlockEntityTypes.TRAPPED_CHEST) && blockInfo.nbt() != null) {

      ListTag items = blockInfo.nbt().getListOrEmpty("Items");

      if (items.size() == 2) {

        List<Integer> mappedList = items
            .stream()
            .map(Tag::asCompound)
            .map(tagOptional -> {
              if (tagOptional.isPresent()) {
                CompoundTag tag = tagOptional.get();
                String item = tag.getStringOr("id", "minecraft:air");
                int count = tag.getIntOr("count", 0);
                if (item.equals("minecraft:ender_pearl") && count == 1) {
                  var slot = tag.getByteOr("Slot", (byte)255);
                  if (slot == (byte)11) return 1;
                  else if (slot == (byte)15) return 2;
                }
              }
              return 0;
            })
            .sorted()
            .toList();

        if (mappedList.size() == 2 && mappedList.getFirst() == 1 && mappedList.getLast() == 2) {

          ItemStackTemplate itemStack = new ItemStackTemplate(
              Items.WOODEN_PICKAXE,
              DataComponentPatch.builder()
                  .set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
                  .set(DataComponents.CUSTOM_DATA, CustomData.of(
                      (CompoundTag)NbtOps.INSTANCE.createMap(
                          Map.of(
                              StringTag.valueOf("breaks_end_portal_frames"),
                              ByteTag.valueOf(true)
                          )
                      )
                  ))
                  .set(DataComponents.UNBREAKABLE, Unit.INSTANCE)
                  .set(DataComponents.CUSTOM_NAME, Component.literal("The Pickaxe That Can Mine End Portal Frames").withStyle(ChatFormatting.AQUA))
                  .set(DataComponents.LORE, new ItemLore(List.of(Component.literal("You need to visit a stronghold portal room, and get an advancement, before mining end portal frames.").withStyle(ChatFormatting.GRAY).withStyle(ChatFormatting.ITALIC))))
                  .build()
          );

          CompoundTag item11 = new CompoundTag();
          item11.putInt("count", 1);
          item11.putString("id", "minecraft:ender_pearl");
          item11.putByte("Slot", (byte)11);

          CompoundTag item13 = new CompoundTag();
          item13.store(ItemStackTemplate.MAP_CODEC, itemStack);
          item13.putByte("Slot", (byte)13);

          CompoundTag item15 = new CompoundTag();
          item15.putInt("count", 1);
          item15.putString("id", "minecraft:ender_pearl");
          item15.putByte("Slot", (byte)15);

          ListTag items2 = new ListTag();
          items2.add(item11);
          items2.add(item13);
          items2.add(item15);
          CompoundTag tag2 = new CompoundTag();
          tag2.put("Items", items2);

          blockEntity.loadWithComponents(TagValueInput.create(
              ProblemReporter.DISCARDING,
              level.registryAccess(),
              tag2
          ));

        }

      }
    }
  }

}
