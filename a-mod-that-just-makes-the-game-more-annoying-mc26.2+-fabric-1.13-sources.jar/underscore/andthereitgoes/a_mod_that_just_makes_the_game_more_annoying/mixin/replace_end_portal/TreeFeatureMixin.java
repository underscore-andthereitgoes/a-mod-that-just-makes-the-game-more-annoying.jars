package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.replace_end_portal;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;
import net.minecraft.world.level.levelgen.feature.TreeFeature;
import net.minecraft.world.level.levelgen.feature.configurations.TreeConfiguration;
import net.minecraft.world.level.levelgen.feature.foliageplacers.FoliagePlacer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.function.BiConsumer;


@Mixin(TreeFeature.class)
public abstract class TreeFeatureMixin {
  @Inject(method = "doPlace", at = @At("RETURN"))
  private void doPlaceExtraEndPortal(WorldGenLevel level, RandomSource random, BlockPos origin, BiConsumer<BlockPos,BlockState> rootSetter, BiConsumer<BlockPos,BlockState> trunkSetter, FoliagePlacer.FoliageSetter foliageSetter, TreeConfiguration config, CallbackInfoReturnable<Boolean> cir) {
    if (!Config.REPLACE_END_PORTAL.get()) return;
    if (cir.getReturnValue() && level.getMinY() <= -63) {
      PositionalRandomFactory forked = random.forkPositional();
      BlockPos pos = origin.atY(-62);
      RandomSource posrandom = forked.at(pos);
      if (posrandom.nextDouble() < 0.00125) {
        BlockState state = Blocks.END_PORTAL_FRAME.defaultBlockState().rotate(Rotation.getRandom(posrandom));
        level.setBlock(pos, state, 2);
      }
    }
  }
}
