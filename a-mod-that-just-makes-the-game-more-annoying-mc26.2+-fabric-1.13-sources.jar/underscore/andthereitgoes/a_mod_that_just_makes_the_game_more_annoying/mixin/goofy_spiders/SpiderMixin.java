package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.goofy_spiders;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.spider.Spider;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.SpiderLeapAtTargetGoal;


@Mixin(Spider.class)
public abstract class SpiderMixin extends Monster {
  protected SpiderMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Redirect(
      method = "registerGoals",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V"
      )
  )
  private void newLeapAtTargetGoal(GoalSelector instance, int prio, Goal goal) {
    if (!Config.GOOFY_SPIDERS.get()) {
      instance.addGoal(prio, goal);
      return;
    }
    if (goal instanceof LeapAtTargetGoal) {
      instance.addGoal(prio, new SpiderLeapAtTargetGoal(this, 0.55f));
    } else {
      instance.addGoal(prio, goal);
    }
  }

  @Inject(method = "createAttributes", at = @At("TAIL"), cancellable = true)
  private static void createExtraAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (!Config.GOOFY_SPIDERS.get()) return;
    cir.setReturnValue(
        cir.getReturnValue()
          .add(Attributes.FOLLOW_RANGE, 96.0d)
          .add(Attributes.FALL_DAMAGE_MULTIPLIER, 0.0d)
    );
  }
}
