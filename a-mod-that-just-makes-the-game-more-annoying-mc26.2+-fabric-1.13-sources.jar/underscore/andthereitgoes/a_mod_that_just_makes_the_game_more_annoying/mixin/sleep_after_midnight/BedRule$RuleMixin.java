package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.sleep_after_midnight;

import net.minecraft.world.attribute.BedRule;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BedRule.Rule.class)
public abstract class BedRule$RuleMixin {

  @Redirect(
      method = "test",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/level/Level;isDarkOutside()Z"
      )
  )
  private boolean redirectIsDarkOutside(Level instance) {
    if (!Config.SLEEP_AFTER_MIDNIGHT.get()) return instance.isDarkOutside();
    return instance.isDarkOutside() && ((instance.getDefaultClockTime() % 24000L) > 18000L);
  }

}
