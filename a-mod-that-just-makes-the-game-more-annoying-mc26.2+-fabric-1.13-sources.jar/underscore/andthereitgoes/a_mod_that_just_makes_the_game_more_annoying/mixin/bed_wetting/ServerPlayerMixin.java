package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.bed_wetting;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "stopSleepInBed", at = @At("TAIL"))
  private void stopSleepInBedTAIL_(CallbackInfo ci) {
    if (!Config.BED_WETTING.get()) return;
    if (!this.isSpectator() && this.random.nextDouble() < 0.2d) {
      this.getSleepingPos().ifPresent(sleepingPos -> {
        BlockState headBlock = this.level().getBlockState(sleepingPos);
        if (headBlock.is(BlockTags.BEDS)) {
          BlockPos waterPos = sleepingPos.relative(headBlock.getValue(BedBlock.FACING).getOpposite()).above();
          if (this.level().getFluidState(waterPos).isEmpty() && this.level().getBlockState(waterPos).isAir()) {
            this.level().setBlockAndUpdate(waterPos, Blocks.WATER.defaultBlockState());
          }
        }
      });
    }
  }

}
