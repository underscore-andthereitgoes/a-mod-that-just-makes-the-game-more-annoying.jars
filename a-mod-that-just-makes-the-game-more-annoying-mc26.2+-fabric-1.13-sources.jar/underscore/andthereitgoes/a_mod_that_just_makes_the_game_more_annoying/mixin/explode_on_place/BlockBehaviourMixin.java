package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.explode_on_place;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlockBehaviour.class)
public abstract class BlockBehaviourMixin {

  @Inject(method = "onPlace", at = @At("TAIL"))
  private void extraOnPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston, CallbackInfo ci) {
    if (Config.EXPLODE_ON_PLACE.get()) {
      if (level.getRandom().forkPositional().at(pos).nextDouble() < 0.00025d) {
        level.explode(null, pos.getX() + 0.5d, pos.getY() + 0.5d, pos.getZ() + 0.5d, 2.0f, false, Level.ExplosionInteraction.BLOCK);
      }
    }
  }

}
