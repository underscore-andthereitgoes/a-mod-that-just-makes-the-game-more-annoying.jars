package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.explosive_rabbits;

import com.mojang.math.Transformation;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.rabbit.Rabbit;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Rabbit.class)
public abstract class RabbitMixin extends Animal {

  protected RabbitMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Inject(method = "baseTick", at = @At("TAIL"))
  private void extraTick(CallbackInfo ci) {
    if (Config.EXPLOSIVE_RABBITS.get() && !this.isDeadOrDying() && this.tickCount % 100 == 1 && !this.hasPassenger(e -> e.is(EntityTypes.BLOCK_DISPLAY))) {
      Level level = this.level();
      if (!level.isClientSide()) {
        Display.BlockDisplay blockDisplay = new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY, level);
        blockDisplay.setBlockState(Blocks.TNT.defaultBlockState());
        Transformation transgender = new Transformation(
            new Matrix4f()
                .scale(0.8f)
                .translate(-0.4f, 0.3f, -0.4f)
        );
        blockDisplay.setTransformation(transgender);
        blockDisplay.getEntityData().set(Display.DATA_WIDTH_ID, 0.8f);
        blockDisplay.getEntityData().set(Display.DATA_HEIGHT_ID, 0.8f);
        level.addFreshEntity(blockDisplay);
        blockDisplay.addTag("rabbit_bomb");
        blockDisplay.startRiding(this);
      }
    }
  }

}
