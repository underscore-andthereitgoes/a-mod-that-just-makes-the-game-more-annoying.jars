package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.tall_lands;

import net.minecraft.world.level.levelgen.DensityFunction;
import net.minecraft.world.level.levelgen.synth.BlendedNoise;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(BlendedNoise.class)
public abstract class BlendedNoiseMixin {
  @Inject(method = "compute", at = @At("RETURN"), cancellable = true)
  private void computeRETURN(DensityFunction.FunctionContext context, CallbackInfoReturnable<Double> cir) {
    if (Config.TALL_LANDS.get()) {
      cir.setReturnValue(cir.getReturnValue() * 128.0d);
    }
  }
}
