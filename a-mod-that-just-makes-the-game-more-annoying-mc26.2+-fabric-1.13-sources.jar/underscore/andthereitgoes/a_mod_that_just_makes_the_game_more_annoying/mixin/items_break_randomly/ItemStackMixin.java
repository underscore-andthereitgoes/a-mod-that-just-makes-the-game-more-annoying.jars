package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.items_break_randomly;

import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
  @Shadow
  public abstract int getMaxDamage();

  @ModifyVariable(
      method = "applyDamage",
      at = @At("HEAD"),
      name = "newDamage",
      argsOnly = true
  )
  private int modifyNewDamage(int newDamage) {
    if (!Config.ITEMS_BREAK_RANDOMLY.get()) return newDamage;
    if (Math.random() < 0.02) {
      return this.getMaxDamage();
    } else return newDamage;
  }
}
