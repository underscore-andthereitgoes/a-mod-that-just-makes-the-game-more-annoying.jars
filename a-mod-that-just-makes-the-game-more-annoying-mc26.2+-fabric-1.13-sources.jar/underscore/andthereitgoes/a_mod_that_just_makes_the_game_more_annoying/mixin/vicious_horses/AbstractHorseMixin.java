package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.vicious_horses;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractHorse.class)
public abstract class AbstractHorseMixin extends Animal {
  protected AbstractHorseMixin(EntityType<? extends Animal> type, Level level) {
    super(type, level);
  }

  @Redirect(method = "registerGoals", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/GoalSelector;addGoal(ILnet/minecraft/world/entity/ai/goal/Goal;)V"))
  private void redirectAddGoal(GoalSelector instance, int prio, Goal goal) {
    if (Config.VICIOUS_HORSES.get()) {
      if (prio == 1) {
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 2.0d, true));
        return;
      }
    }
    instance.addGoal(prio, goal);
  }

  @Inject(method = "createBaseHorseAttributes", at = @At("TAIL"))
  private static void addExtraAttributes(CallbackInfoReturnable<AttributeSupplier.Builder> cir) {
    if (!Config.VICIOUS_HORSES.get()) return;
    cir.getReturnValue()
        .add(Attributes.ATTACK_DAMAGE, 5.0f)
        .add(Attributes.ATTACK_KNOCKBACK, 2.0f)
    ;
  }

}
