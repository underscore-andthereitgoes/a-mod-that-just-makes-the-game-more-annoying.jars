package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.destroying_blocks_with_hand_hurts;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayerGameMode.class)
public abstract class ServerPlayerGameModeMixin {
  @Shadow
  private boolean isDestroyingBlock;

  @Shadow
  @Final
  protected ServerPlayer player;

  @Inject(method = "tick", at = @At("TAIL"))
  private void tickTAIL_handMinedBlocksHurt(CallbackInfo ci) {
    if (!Config.DESTROYING_BLOCKS_WITH_HAND_HURTS.get()) return;
    if (this.isDestroyingBlock) {
      if (this.player.getMainHandItem().isEmpty()) {
        ServerLevel serverLevel = this.player.level();
        if (player.hurtTime == 0) {
          player.hurtServer(serverLevel, serverLevel.damageSources().cactus(), 2.0f);
        }
      }
    }
  }
}
