package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.always_spawn_phantoms;

import com.llamalad7.mixinextras.expression.Definition;import com.llamalad7.mixinextras.expression.Expression;import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.level.levelgen.PhantomSpawner;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(PhantomSpawner.class)
public abstract class PhantomSpawnerMixin {
  @Definition(id="clamp", method="Lnet/minecraft/util/Mth;clamp(III)I")
  @Expression("clamp(?, ?, ?)")
  @ModifyExpressionValue(method="tick", at=@At("MIXINEXTRAS:EXPRESSION"))
  private static int overwrite(int original) {
    if (!Config.ALWAYS_SPAWN_PHANTOMS.get()) return original;
    return Integer.MAX_VALUE;
  }
}
