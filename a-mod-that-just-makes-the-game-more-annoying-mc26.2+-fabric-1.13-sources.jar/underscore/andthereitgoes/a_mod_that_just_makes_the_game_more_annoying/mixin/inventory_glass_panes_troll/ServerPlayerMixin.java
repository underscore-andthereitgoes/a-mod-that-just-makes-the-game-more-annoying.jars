package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.inventory_glass_panes_troll;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {
  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("HEAD"))
  private void tickHEAD_inventoryTroll(CallbackInfo ci) {
    if (!Config.INVENTORY_GLASS_PANES_TROLL.get()) return;
    if (this.tickCount % 40 != 0) return;
    if (!this.isSpectator() && Math.random() < 0.2d) {
      Inventory inventory = this.getInventory();
      List<Integer> freeSlots = new ArrayList<>();
      for(int i = 10; i < 36; ++i) {
        if (inventory.getItem(i).isEmpty()) {
          freeSlots.add(i);
        }
      }
      if (!freeSlots.isEmpty()) {
        int slot = freeSlots.get(Mth.floor(Math.random() * freeSlots.size()));
        ItemStack stack = new ItemStack(Items.STAINED_GLASS_PANE.lightGray(), 1);
        var enchantmentRegistry = this.level().registryAccess().lookup(Registries.ENCHANTMENT).orElseThrow();
        stack.enchant(enchantmentRegistry.wrapAsHolder(Objects.requireNonNull(enchantmentRegistry.getValue(Enchantments.VANISHING_CURSE))), 1);
        stack.applyComponents(
            DataComponentPatch.builder()
                .set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, false)
                .set(DataComponents.TOOLTIP_DISPLAY, new TooltipDisplay(true, new LinkedHashSet<>(List.of(DataComponents.ENCHANTMENTS))))
                .set(DataComponents.MAX_STACK_SIZE, 1)
                .build()
        );
        inventory.add(slot, stack);
      }
    }
  }

}
