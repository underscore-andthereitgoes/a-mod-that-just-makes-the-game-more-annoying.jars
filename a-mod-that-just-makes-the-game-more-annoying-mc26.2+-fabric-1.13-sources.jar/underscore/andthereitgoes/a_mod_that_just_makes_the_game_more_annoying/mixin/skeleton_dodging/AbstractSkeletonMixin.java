package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.skeleton_dodging;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractSkeleton.class)
public abstract class AbstractSkeletonMixin extends Monster {
  protected AbstractSkeletonMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Unique
  private boolean canFit(ServerLevel level, Vec3 where) {
    return level.getBlockStatesIfLoaded(this.makeBoundingBox(where)).allMatch(BlockState::isAir);
  }

  @Unique
  private @Nullable Vec3 findEscapePosition(ServerLevel level) {
    Vec3 center = this.position();
    for (double d = 3d + 2d * Math.random(); d < 20d; d *= 1.25d) {
      double angle = Math.random() * Math.PI * 2d;
      double dx = Math.cos(angle) * d;
      double dz = Math.sin(angle) * d;
      for (int y = -3; y <= 3; y++) {
        Vec3 where = center.add(dx, y, dz);
        if (canFit(level, where) && !canFit(level, where.subtract(0d, 1d, 0d))) return where;
      }
    }
    return null;
  }

  @Override
  public boolean hurtServer(@NonNull ServerLevel level, @NonNull DamageSource source, float damage) {
    boolean hurt = true;
    if (Config.SKELETON_DODGING.get()) {
      if (source.is(DamageTypes.PLAYER_ATTACK) || source.is(DamageTypes.MOB_ATTACK)) {
        Vec3 escapePosition = this.findEscapePosition(level);
        if (escapePosition != null) {
          Vec3 position = this.position();
          AABB aabb = this.getBoundingBox();
          Vec3 aabbCenter = aabb.getCenter();

          level.playSound(null, position.x, position.y, position.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1f, 1.8f);
          level.sendParticles(ParticleTypes.WHITE_SMOKE, false, false, aabbCenter.x, aabbCenter.y, aabbCenter.z, 1024, aabb.getXsize() / 3d, aabb.getYsize() / 3d, aabb.getZsize() / 3d, 0.1d);
          double distance = Math.sqrt(this.distanceToSqr(escapePosition));
          int numSteps = (int)(distance * 5d);
          for (int step = 1; step < numSteps; step++) {
            double fraction = (double)step / numSteps;
            Vec3 fractionalPos = position.lerp(escapePosition, fraction);
            level.sendParticles(ParticleTypes.WHITE_SMOKE, false, false, fractionalPos.x, fractionalPos.y, fractionalPos.z, 8, aabb.getXsize() / 6d, 0d, aabb.getZsize() / 6d, 0.1d);
          }

          this.teleportTo(escapePosition.x, escapePosition.y, escapePosition.z);
          LivingEntity target = this.getTarget();
          if (target != null) {
            Vec2 rot = target.getEyePosition().subtract(escapePosition.add(0d, this.getEyeHeight(), 0d)).rotation();
            this.setXRot(rot.x);
            this.setYRot(rot.y);
          }

          this.resolveMobResponsibleForDamage(source);
          hurt = false;
        }
      } else if (source.is(DamageTypes.ARROW) && source.getEntity() != null && source.getEntity() instanceof AbstractSkeleton) hurt = false;
    }
    if (hurt) return super.hurtServer(level, source, damage);
    else return false;
  }
}
