package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.altitude_temperature_damage;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import org.jspecify.annotations.NonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract @NonNull ServerLevel level();

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (!Config.ALTITUDE_TEMPERATURE_DAMAGE.get()) return;
    if (!this.isSpectator() && this.tickCount % 20 == 0) {
      ServerLevel level = this.level();
      double altitude = this.position().y;
      if (altitude < 0.0d) {
        if (this.tickCount % 40 == 0) {
          this.hurtServer(level, level.damageSources().onFire(), 1.0f);
        }
      } else if (altitude > 256.0d) {
        this.hurtServer(level, level.damageSources().freeze(), 1.0f);
      }
    }
  }

}
