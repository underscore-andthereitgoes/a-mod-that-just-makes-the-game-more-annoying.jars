package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.fall_heart_attacks;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

  @Shadow
  public abstract ServerLevel level();

  @Shadow
  public abstract boolean hurtServer(ServerLevel level, DamageSource source, float damage);

  public ServerPlayerMixin(Level level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void postTick(CallbackInfo ci) {
    if (Config.FALL_HEART_ATTACKS.get()) {
      if (this.tickCount % 100 == 0) {
        if (this.random.nextDouble() < 0.0002d) {
          this.hurtServer(this.level(), this.level().damageSources().fall(), 1000000000.0f);
        }
      }
    }
  }

}
