package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.normal_rails_are_powered_off;

import net.minecraft.world.entity.vehicle.minecart.NewMinecartBehavior;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.PoweredRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(NewMinecartBehavior.class)
public class NewMinecartBehaviorMixin {

  @ModifyVariable(method = "calculateHaltTrackSpeed", at = @At("HEAD"), name = "state", argsOnly = true)
  private BlockState changeBlockState(BlockState state) {
    if (Config.NORMAL_RAILS_ARE_POWERED_OFF.get()) {
      if (state.is(Blocks.POWERED_RAIL)) return state;
      else return Blocks.POWERED_RAIL.defaultBlockState().setValue(PoweredRailBlock.POWERED, false);
    }
    return state;
  }

}
