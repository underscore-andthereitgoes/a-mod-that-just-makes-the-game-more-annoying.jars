package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.shield_blocking_disables;

import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BlocksAttacks;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;

import java.util.Optional;


@Mixin(BlocksAttacks.class)
public abstract class BlocksAttacksMixin {
  @Shadow
  public abstract Optional<Holder<SoundEvent>> disableSound();

  @Inject(method = "hurtBlockingItem", at = @At("TAIL"))
  private void hurtBlockingItemTAIL(Level level, ItemStack item, LivingEntity user, InteractionHand hand, float damage, CallbackInfo ci) {
    if (!Config.SHIELD_BLOCKING_DISABLES.get()) return;
    if (user instanceof Player player) {
      if (player.getRandom().nextDouble() < 0.25) {
        player.stopUsingItem();
        player.getCooldowns().addCooldown(item, 100);
        this.disableSound().ifPresent((sound) -> level.playSound(null, user.getX(), user.getY(), user.getZ(), sound, user.getSoundSource(), 0.8F, 0.8F + level.getRandom().nextFloat() * 0.4F));
      }
    }
  }
}
