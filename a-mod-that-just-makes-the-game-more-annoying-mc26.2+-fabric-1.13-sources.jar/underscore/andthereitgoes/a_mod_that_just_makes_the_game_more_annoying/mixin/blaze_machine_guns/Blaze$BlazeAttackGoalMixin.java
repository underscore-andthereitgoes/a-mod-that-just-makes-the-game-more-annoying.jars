package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.blaze_machine_guns;

import net.minecraft.world.entity.monster.Blaze;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Blaze.BlazeAttackGoal.class)
public class Blaze$BlazeAttackGoalMixin {

  @Shadow
  private int attackStep;

  @Shadow
  private int attackTime;

  @Inject(method = "tick", at = @At("HEAD"))
  private void preTick(CallbackInfo ci) {
    if (Config.BLAZE_MACHINE_GUNS.get()) {
      if (this.attackStep > 3) this.attackStep = 3;
      if (this.attackTime > 6) this.attackTime = 6;
    }
  }
}
