package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.no_xp;

import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Player.class)
public abstract class PlayerMixin {

  @Inject(method = "giveExperiencePoints", at = @At("HEAD"), cancellable = true)
  private void stopXP(int i, CallbackInfo ci) {
    if (Config.NO_XP.get()) ci.cancel();
  }
}
