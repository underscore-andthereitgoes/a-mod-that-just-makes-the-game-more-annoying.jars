package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin._global;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;


@Mixin(TitleScreen.class)
@Environment(EnvType.CLIENT)
public abstract class TitleScreenMixin extends Screen {
  protected TitleScreenMixin(Component title) {
    super(title);
  }

//  private Button modOptionsButton = null;

//  @Inject(method = "init", at = @At("TAIL"))
//  private void initExtraButtons(CallbackInfo ci) {
    /*
    modOptionsButton =
        Button.builder(
                Component.literal("Minecraft Ragebait Edition options"),
                button -> this.minecraft.setScreen(new AMTJMTGMAOptionsScreen())
            )
            .bounds(
                this.width / 2 - 109,60,
                218, 27
            )
        .build();
    this.addWidget(modOptionsButton);
    this.addRenderableOnly((graphics, mouseX, mouseY, a) -> {
      if (modOptionsButton.isMouseOver(mouseX, mouseY)) {
        for (int i = 0; i < AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.size(); i += 5) {
          var x0 = AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.get(i);
          var y0 = AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.get(i+1);
          var x1 = x0+AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.get(i+2);
          var y1 = y0+AMTJMTGMAScreenConstants.EDITION_BOXES_CALCULATED.get(i+3);
          if (mouseX >= x0 && mouseX < x1 && mouseY >= y0 && mouseY < y1) {
            graphics.requestCursor(CursorTypes.POINTING_HAND);
            break;
          }
        }
      }
    });
   */
//  }

}
