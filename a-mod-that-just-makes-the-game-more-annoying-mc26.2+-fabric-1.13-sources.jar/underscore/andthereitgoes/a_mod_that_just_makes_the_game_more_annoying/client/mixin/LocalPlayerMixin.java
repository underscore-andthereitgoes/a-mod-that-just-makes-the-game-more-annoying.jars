package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.data.worldgen.DimensionTypes;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.level.dimension.DimensionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.TTSGuide;


@Mixin(LocalPlayer.class)
@Environment(EnvType.CLIENT)
public abstract class LocalPlayerMixin extends AbstractClientPlayer {
  public LocalPlayerMixin(ClientLevel level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @Inject(method = "isShiftKeyDown", at = @At("TAIL"), cancellable = true)
  private void isShiftKeyDownNow(CallbackInfoReturnable<Boolean> cir) {
    if (!Config.RANDOMLY_STOP_SNEAKING_IN_NETHER.get()) return;
    if (this.level().dimension() == ClientLevel.NETHER) {
      if (Math.random() < 0.002) {
        cir.setReturnValue(false);
      }
    }
  }

  @Inject(method = "tickDeath", at = @At("HEAD"))
  private void tickDeathHEAD(CallbackInfo ci) {
    if (!Config.TTS_GUIDE.get()) return;
    if (this.deathTime == 0) {
      TTSGuide.provideDeathAdvice((ClientLevel)this.level(), (LocalPlayer)(Object)this, this.getLastDamageSource());
    }
  }

}
