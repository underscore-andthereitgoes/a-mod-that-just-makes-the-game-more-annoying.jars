package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin.invisible_creepers;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.entity.CreeperRenderer;
import net.minecraft.client.renderer.entity.state.CreeperRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(CreeperRenderer.class)
@Environment(EnvType.CLIENT)
public abstract class CreeperRendererMixin {
  @Shadow
  protected abstract float getWhiteOverlayProgress(CreeperRenderState state);

  @Inject(method = "scale(Lnet/minecraft/client/renderer/entity/state/CreeperRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;)V", at = @At("TAIL"))
  private void scaleTAIL(CreeperRenderState state, PoseStack poseStack, CallbackInfo ci) {
    if (!Config.INVISIBLE_CREEPERS.get()) return;
    boolean notWhite = this.getWhiteOverlayProgress(state) < 0.5f;
    if (notWhite) {
      poseStack.scale(0.0f, 0.0f, 0.0f);
    }
  }
}
