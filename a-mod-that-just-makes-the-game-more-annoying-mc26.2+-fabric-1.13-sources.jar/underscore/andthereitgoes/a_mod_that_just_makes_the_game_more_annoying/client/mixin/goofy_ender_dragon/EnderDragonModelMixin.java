package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin.goofy_ender_dragon;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.monster.dragon.EnderDragonModel;
import net.minecraft.client.renderer.entity.state.EnderDragonRenderState;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(EnderDragonModel.class)
@Environment(EnvType.CLIENT)
public abstract class EnderDragonModelMixin {

  @Shadow
  @Final
  private ModelPart body;

  @Shadow
  @Final
  private ModelPart leftWing;

  @Shadow
  @Final
  private ModelPart leftWingTip;

  @Shadow
  @Final
  private ModelPart leftFrontLeg;

  @Shadow
  @Final
  private ModelPart leftFrontLegTip;

  @Shadow
  @Final
  private ModelPart leftFrontFoot;

  @Shadow
  @Final
  private ModelPart leftRearLeg;

  @Shadow
  @Final
  private ModelPart leftRearLegTip;

  @Shadow
  @Final
  private ModelPart leftRearFoot;

  @Shadow
  @Final
  private ModelPart rightWing;

  @Shadow
  @Final
  private ModelPart rightWingTip;

  @Shadow
  @Final
  private ModelPart rightFrontLeg;

  @Shadow
  @Final
  private ModelPart rightFrontLegTip;

  @Shadow
  @Final
  private ModelPart rightFrontFoot;

  @Shadow
  @Final
  private ModelPart rightRearLeg;

  @Shadow
  @Final
  private ModelPart rightRearLegTip;

  @Shadow
  @Final
  private ModelPart rightRearFoot;

  @Dynamic
  @Unique
  private void clear(ModelPart part) {
    part.xRot = 0f;
    part.yRot = 0f;
    part.zRot = 0f;
    part.xScale = 1f;
    part.yScale = 1f;
    part.zScale = 1f;
  }

  @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/EnderDragonRenderState;)V", at = @At("HEAD"), cancellable = true)
  public void setupAnim(EnderDragonRenderState state, CallbackInfo ci) {
    if (!Config.GOOFY_ENDER_DRAGON.get()) return;
    clear(this.body);
    clear(this.leftWing);
    clear(this.leftWingTip);
    clear(this.leftFrontLeg);
    clear(this.leftFrontLegTip);
    clear(this.leftFrontFoot);
    clear(this.leftRearLeg);
    clear(this.leftRearLegTip);
    clear(this.leftRearFoot);
    clear(this.rightWing);
    clear(this.rightWingTip);
    clear(this.rightFrontLeg);
    clear(this.rightFrontLegTip);
    clear(this.rightFrontFoot);
    clear(this.rightRearLeg);
    clear(this.rightRearLegTip);
    clear(this.rightRearFoot);
    ci.cancel();
  }
}
