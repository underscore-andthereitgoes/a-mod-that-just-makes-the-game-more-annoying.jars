package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin.tiny_tooltips;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.TooltipRenderUtil;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Environment(EnvType.CLIENT)
@Mixin(TooltipRenderUtil.class)
public class TooltipRenderUtilMixin {

  @Inject(method = "extractTooltipBackground", at = @At("HEAD"), cancellable = true)
  private static void cancelTooltip(GuiGraphicsExtractor graphics, int x, int y, int w, int h, Identifier style, CallbackInfo ci) {
    if (Config.REMOVE_TOOLTIP_BACKGROUNDS.get()) ci.cancel();
  }

}
