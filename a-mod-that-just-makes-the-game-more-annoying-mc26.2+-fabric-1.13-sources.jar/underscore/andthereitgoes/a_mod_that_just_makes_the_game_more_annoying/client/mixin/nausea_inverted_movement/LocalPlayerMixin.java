package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.client.mixin.nausea_inverted_movement;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Environment(EnvType.CLIENT)
@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin extends AbstractClientPlayer {

  public LocalPlayerMixin(ClientLevel level, GameProfile gameProfile) {
    super(level, gameProfile);
  }

  @ModifyReturnValue(method = "modifyInput", at = @At("RETURN"))
  private Vec2 invertMovementIfNausea(Vec2 movement) {
    if (Config.NAUSEA_INVERTED_MOVEMENT.get() && this.hasEffect(MobEffects.NAUSEA)) return movement.negated();
    return movement;
  }

}
