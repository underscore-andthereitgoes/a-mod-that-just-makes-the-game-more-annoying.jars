package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.increased_player_height;

import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(Avatar.class)
public abstract class AvatarMixin {

  @Inject(method = "getDefaultDimensions", at = @At("TAIL"))
  private void modifyDimensions(Pose pose, CallbackInfoReturnable<EntityDimensions> cir) {
    if (Config.INCREASED_PLAYER_HEIGHT.get()) cir.getReturnValue().height += 0.2f;
  }

}
