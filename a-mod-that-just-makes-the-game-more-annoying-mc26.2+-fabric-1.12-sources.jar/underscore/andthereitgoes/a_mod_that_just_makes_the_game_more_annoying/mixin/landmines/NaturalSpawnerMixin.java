package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.landmines;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(NaturalSpawner.class)
public abstract class NaturalSpawnerMixin {

  @Inject(method = "spawnCategoryForPosition(Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/NaturalSpawner$SpawnPredicate;Lnet/minecraft/world/level/NaturalSpawner$AfterSpawnCallback;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Mob;snapTo(DDDFF)V"))
  private static void potentiallySpawnLandmine(
      MobCategory mobCategory, ServerLevel level, ChunkAccess chunk, BlockPos start, NaturalSpawner.SpawnPredicate extraTest, NaturalSpawner.AfterSpawnCallback spawnCallback, CallbackInfo ci,
      @Local(name = "xx") double xx,
      @Local(name = "yStart") int yStart,
      @Local(name = "zz") double zz
  ) {
    if (mobCategory == MobCategory.CREATURE || mobCategory == MobCategory.MONSTER) {
      if (Math.random() < 0.01d) {
        Display.BlockDisplay landmine = new Display.BlockDisplay(EntityTypes.BLOCK_DISPLAY, level);
        landmine.setPos(new Vec3(xx, yStart - 1, zz));
        landmine.addTag("landmine");
        level.addFreshEntity(landmine);
      }
    }
  }

}
