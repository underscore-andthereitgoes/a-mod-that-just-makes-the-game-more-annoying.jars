package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.skeleton_dodging;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(AbstractSkeleton.class)
public abstract class AbstractSkeletonMixin extends Monster {
  protected AbstractSkeletonMixin(EntityType<? extends Monster> type, Level level) {
    super(type, level);
  }

  @Unique
  private boolean canFit(ServerLevel level, Vec3 where) {
    return level.getBlockStatesIfLoaded(this.makeBoundingBox(where)).allMatch(BlockState::isAir);
  }

  @Unique
  private @Nullable Vec3 findEscapePosition(ServerLevel level) {
    Vec3 center = this.position();
    for (double d = 3d + 2d * Math.random(); d < 30d; d *= 1.25d) {
      double angle = Math.random() * Math.PI * 2d;
      double dx = Math.cos(angle) * d;
      double dz = Math.sin(angle) * d;
      for (int y = -3; y <= 3; y++) {
        Vec3 where = center.add(dx, y, dz);
        if (canFit(level, where)) return where;
      }
    }
    return null;
  }

  @Override
  public boolean isInvulnerableTo(@NonNull ServerLevel level, @NonNull DamageSource source) {
    return super.isInvulnerableTo(level, source) || (Config.SKELETON_DODGING.get() && (source.is(DamageTypes.PLAYER_ATTACK) || source.is(DamageTypes.MOB_ATTACK)));
  }

  @Override
  public boolean hurtServer(@NonNull ServerLevel level, @NonNull DamageSource source, float damage) {
    if (Config.SKELETON_DODGING.get() && (source.is(DamageTypes.PLAYER_ATTACK) || source.is(DamageTypes.MOB_ATTACK))) {
      Vec3 escapePosition = this.findEscapePosition(level);
      if (escapePosition != null) {
        AABB aabb = this.getBoundingBox();
        Vec3 aabbCenter = aabb.getCenter();
        level.sendParticles(ParticleTypes.WHITE_SMOKE, false, false, aabbCenter.x, aabbCenter.y, aabbCenter.z, 256, aabb.getXsize() / 3.5d, aabb.getYsize() / 3.5d, aabb.getZsize() / 3.5d, 0.1d);
        this.snapTo(escapePosition.x, escapePosition.y, escapePosition.z);
        LivingEntity target = this.getTarget();
        if (target != null) {
          Vec2 rot = target.getEyePosition().subtract(escapePosition.add(0d, this.getEyeHeight(), 0d)).rotation();
          this.setRot(rot.y, rot.x);
        }
        this.heal(damage);
        this.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 5, 0, true, false));
      }
    }
    this.resolveMobResponsibleForDamage(source);
    return super.hurtServer(level, source, damage);
  }
}
