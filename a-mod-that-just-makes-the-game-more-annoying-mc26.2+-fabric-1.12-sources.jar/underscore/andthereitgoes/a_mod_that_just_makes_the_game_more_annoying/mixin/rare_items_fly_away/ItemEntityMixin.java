package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.rare_items_fly_away;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.Config;


@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin extends Entity {
  @Shadow
  public abstract ItemStack getItem();

  public ItemEntityMixin(EntityType<?> type, Level level) {
    super(type, level);
  }

  @Inject(method = "tick", at = @At("TAIL"))
  private void extraTick(CallbackInfo ci) {
    if (Config.RARE_ITEMS_FLY_AWAY.get()) {
      ItemStack itemstack = this.getItem();
      if (itemstack.getRarity() != Rarity.COMMON
          || itemstack.is(ItemTags.TRIM_MATERIALS)
          || itemstack.is(ItemTags.BEACON_PAYMENT_ITEMS)
          || itemstack.is(ItemTags.PIGLIN_LOVED)
          || itemstack.is(ItemTags.BOOKSHELF_BOOKS)
      ) {
        this.level()
            .getEntitiesOfClass(Player.class, AABB.ofSize(this.position(), 8.0d, 8.0d, 8.0d))
            .stream().forEach((entity) -> {
              var diff = this.position().subtract(entity.position());
              if (diff.lengthSqr() < 64.0) this.addDeltaMovement(diff.normalize().scale(0.1d));
            });
      }
    }
  }

}
