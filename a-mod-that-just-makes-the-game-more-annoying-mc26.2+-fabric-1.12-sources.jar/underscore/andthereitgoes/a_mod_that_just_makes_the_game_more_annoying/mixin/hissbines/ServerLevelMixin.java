package underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.mixin.hissbines;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.entity.EntityTypeTest;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.hissbines.Hissbine;
import underscore.andthereitgoes.a_mod_that_just_makes_the_game_more_annoying.landmines.Landmine;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;
import java.util.stream.Collectors;


@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin {

  @Shadow
  public abstract <T extends Entity> List<? extends T> getEntities(EntityTypeTest<Entity,T> type, Predicate<? super T> selector);

  @Unique
  private final List<Hissbine> hissbines = new ArrayList<>();

  @Inject(method = "addEntity", at = @At("TAIL"))
  private void postAddEntity(Entity entity, CallbackInfoReturnable<Boolean> cir) {
    Hissbine potentialHissbine = Hissbine.maybeAttachEntity(entity);
    if (potentialHissbine != null) {
      this.hissbines.add(potentialHissbine);
    }
  }

  @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;runBlockEvents()V"))
  private void tickLandmines(BooleanSupplier haveTime, CallbackInfo ci) {
    Set<Display.BlockDisplay> countedBlockDisplays = this.hissbines.stream().map(hissbine -> hissbine.seagrass).collect(Collectors.toSet());
    this.getEntities(
        EntityTypeTest.forExactClass(Display.BlockDisplay.class),
        d -> d.entityTags().contains("hissbine") && !countedBlockDisplays.contains(d)
    ).forEach(d -> Optional.ofNullable(Hissbine.maybeAttachEntity(d)).ifPresentOrElse(this.hissbines::add, () -> d.remove(Entity.RemovalReason.DISCARDED)));
    this.hissbines.forEach(Hissbine::tick);
    this.hissbines.removeIf(Hissbine::isRemoved);
  }

}
